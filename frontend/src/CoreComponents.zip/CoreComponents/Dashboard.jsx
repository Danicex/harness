"use client"

import { useEffect, useState, useMemo, lazy, Suspense } from "react"
import {
  Hotel,
  LayoutDashboard,
  Package,
  Settings,
  Users,
  Mail,
  FileText,
  Menu,
  Bell,
  User,
  BotMessageSquare,
  Megaphone,
  Group,
  BookCheck,
  CircleDollarSign,
  History, Database,
  Check, ListTodo
} from "lucide-react"
import { Button } from "@/components/ui/button"
import logo from '../assets/963c7620-ebc1-427c-b9c2-009612cfa83b.png';
import logo2 from '../assets/9afc9890-5863-44a2-9c58-42eebfc842f4.png';
import { useMyContext } from "@/Context/AppContext"
import ThemeToggle from "@/components/ThemeToggle"
import PageSpinner from "@/components/PageSpinner"
import api from "@/lib/api"

// Lazy-loaded tab panels. Each tab's code is only downloaded the first time
// the user actually opens it — paired with <Suspense fallback={<PageSpinner />}>
// below so the rest of the dashboard (sidebar, header) stays interactive
// while a panel's chunk is loading.

const RenderAnalytics = lazy(() => import("./RenderAnalytics"))
const Room = lazy(() => import("./Room"))
const Inventory = lazy(() => import("./Inventory"))
const AutomatedCalls = lazy(() => import("./AutomatedCalls"))
const CampaignsPage = lazy(() => import("./Champagne"))
const CustomerList = lazy(() => import("./CustomerList"))
const CampaignHistory = lazy(() => import("./CampaignHistory"))
const BookingList = lazy(() => import("./Bookings"))
const SalesList = lazy(() => import("./ProductSales"))
const Staff = lazy(() => import("./Staff"))
const Inbox = lazy(() => import("./Inbox"))
const Blog = lazy(() => import("./Blog"))
const Setting = lazy(() => import("./Setting"))
const Chatbot = lazy(() => import("./Chatbot"))
const AttendanceDisplay = lazy(() => import("./AttendanceDisplay"))
const AttendanceScanner = lazy(() => import("@/staff_endpoint/AttendantScanner"))
const ProfilePage = lazy(() => import("@/staff_endpoint/StaffProfile"))
const TaskManagement = lazy(() => import("./TaskManagement"))
const ChatBotWrapper = lazy(() => import("./ChatBotWrapper"))

// NOTE: AttendanceDisplay (the rotating-QR kiosk screen) is intentionally NOT
// wired into this authenticated dashboard. It's meant to run unattended on a
// wall-mounted screen/tablet at the entrance, so it should live on its own
// standalone route (e.g. /kiosk/attendance) outside the login-gated app shell.

/* ------------------------------------------------------------------ */
/*  Navigation                                                        */
/* ------------------------------------------------------------------ */
// Nav is a list of SECTIONS. A section with a `label` renders a small heading
// above its items; a section without one is ungrouped (no heading).

// Every role sees these, appended after their role-specific sections.
// reg_attendant (self check-in scanner) lives here, not per-role, since
// every employee — regardless of role — needs to be able to check themselves in.
const COMMON_TABS = [
  { id: 'reg_attendant', label: 'Register Attendance', icon: User },
  { id: 'chatbot', label: 'Chatbot', icon: BotMessageSquare },
]

const ADMIN_NAV = [
  { items: [{ id: 'home', label: 'Dashboard', icon: LayoutDashboard }] },
  {
    label: 'Operations',
    items: [
      { id: 'room', label: 'Rooms', icon: Hotel },
      { id: 'inventory', label: 'Inventory', icon: Package },
    ],
  },
  {
    label: 'Revenue',
    items: [
      { id: 'sales', label: 'Sales', icon: CircleDollarSign },
      { id: 'bookings', label: 'Bookings', icon: BookCheck },
    ],
  },
  {
    label: 'chatbot',
    items: [
      { id: 'chatbot_wrapper', label: 'ChatBot / Dataset', icon: Database  },
    ],
  },
  {
    label: 'Team',
    items: [
      { id: 'staff', label: 'Staff', icon: Users },
      { id: 'attendance', label: 'Attendance', icon: Check },
      { id: 'task', label: 'Task Management', icon: ListTodo },
    ],
  },
  {
    label: 'Engagement',
    items: [
      { id: 'customers', label: 'Customers', icon: Group },
      { id: 'inbox', label: 'Inbox', icon: Mail },
      { id: 'blog', label: 'Blog', icon: FileText },
    ],
  },
  { items: [{ id: 'settings', label: 'Settings', icon: Settings }] }, // ungrouped
]

// Sections unique to each role. Roles not listed here fall back to DEFAULT_ROLE_NAV.
const ROLE_NAV = {
  admin: ADMIN_NAV,
  manager: ADMIN_NAV, // manager sees the same tabs as admin
  receptionist: [
    {
      items: [
        { id: 'bookings', label: 'Bookings', icon: BookCheck },
        { id: 'profile', label: 'Profile', icon: User },
      ],
    },
  ],
  sales_attendant: [
    {
      items: [
        { id: 'sales', label: 'Sales', icon: CircleDollarSign },
        { id: 'profile', label: 'Profile', icon: User },
      ],
    },
  ],
}

// Roles with no role-specific tabs of their own still get COMMON_TABS
// (which includes Register Attendance) via the ?? fallback below.
const DEFAULT_ROLE_NAV = []

// Which tab a role should land on when they first open the dashboard.
// Roles not listed here keep whatever tab is already active (default: "home").
const DEFAULT_TAB_BY_ROLE = {
  receptionist: 'bookings',
  sales_attendant: 'sales',
}

// One nav list, used by both the desktop sidebar and the mobile drawer.
function NavList({ sections, activeTab, onSelect }) {
  return (
    <nav className="flex flex-col gap-5 overflow-y-auto">
      {sections.map((section, i) => (
        <div
          key={section.label ?? `section-${i}`}
          // ungrouped sections after the first get a divider so they read as separate
          className={`grid gap-1 ${!section.label && i > 0 ? "border-t pt-4" : ""}`}
        >
          {section.label && (
            <p className="px-2 pb-1 text-xs font-medium text-muted-foreground">{section.label}</p>
          )}
          {section.items.map((tab) => {
            const Icon = tab.icon;
            return (
              <Button
                key={tab.id}
                variant="ghost"
                className={`justify-start gap-2 px-2 ${activeTab === tab.id ? "bg-secondary text-secondary-foreground" : "bg-none"}`}
                onClick={() => onSelect(tab.id)}
              >
                <Icon className="h-4 w-4" />
                {tab.label}
              </Button>
            );
          })}
        </div>
      ))}
    </nav>
  )
}

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("home");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const { theme, user_role } = useMyContext()

  const get_admin_profile = async () => {
    try {
      const res = await api.get("/hotel_profile/get_hotel_profile");
      localStorage.setItem("hotel_data", JSON.stringify(res.data))
    } catch (error) {
      console.error("Failed to fetch hotel profile:", error);
    }
  };

  useEffect(() => {
    get_admin_profile();
  }, []);

  // Pure derivation of the visible nav — no side effects, safe in useMemo.
  const navSections = useMemo(() => {
    const roleSections = ROLE_NAV[user_role] ?? DEFAULT_ROLE_NAV;
    if (user_role === "admin") {
      return roleSections;
    }
    return [...roleSections, { items: COMMON_TABS }];
  }, [user_role]);

  // Flat list of every visible tab (used for the header title lookup).
  const tabs = useMemo(() => navSections.flatMap((s) => s.items), [navSections]);

  // Side effect (changing the active tab on role load) lives in its own
  // effect instead of inside useMemo.
  useEffect(() => {
    const defaultTab = DEFAULT_TAB_BY_ROLE[user_role];
    if (defaultTab) {
      setActiveTab(defaultTab);
    }
  }, [user_role]);

  // Component mapping for better performance
  const componentMap = useMemo(() => ({
    home: RenderAnalytics,
    room: Room,
    inventory: Inventory,
    bookings: BookingList,
    reg_attendant: AttendanceScanner,
    sales: SalesList,
    customers: CustomerList,
    campaign_history: CampaignHistory,
    staff: Staff,
    Campaign: CampaignsPage,
    inbox: Inbox,
    chatbot: Chatbot,
    chatbot_wrapper: ChatBotWrapper,
    blog: Blog,
    profile: ProfilePage,
    attendance: AttendanceDisplay,
    automated_calls: AutomatedCalls,
    settings: Setting,
    task: TaskManagement,
  }), []);

  // Render active tab content
  const renderTabContent = () => {
    const Component = componentMap[activeTab];

    // CustomerList needs to be able to jump to the Campaign History tab.
    if (activeTab === "customers") {
      return <Component onNavigate={setActiveTab} />;
    }

    return <Component />;
  };

  // Get current tab label for header
  const currentTabLabel = useMemo(() => {
    const currentTab = tabs.find(tab => tab.id === activeTab);
    return currentTab?.label || 'Dashboard';
  }, [tabs, activeTab]);

  // Toggle sidebar for mobile
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="flex min-h-screen w-[98dvw] overflow-hidden">
      {/* Sidebar */}
      <div className={`hidden w-300px flex-col border-r bg-background p-4 md:flex ${!sidebarOpen ? 'hidden' : ''}`}>
        <div className="flex items-center gap-2 font-semibold text-lg mb-8">
          <div className="flex lg:flex-1 items-center">
            {theme === 'dark' ? (
              <img alt="" src={logo2} className="h-8 w-auto" />
            ) : (
              <img alt="" src={logo} className="h-8 w-auto" />
            )}
            <span className='px-3 font-bold' id='text'>Harness</span>
          </div>
        </div>
        <NavList sections={navSections} activeTab={activeTab} onSelect={setActiveTab} />
      </div>

      {/* Mobile nav */}
      {sidebarOpen && (
        <div className="side-nav hidden max-md:flex h-[100dvh] absolute z-20 w-64 flex-col border-r bg-background p-6">
          <div className="flex items-center gap-2 font-semibold text-lg mb-8">
            <div className="flex lg:flex-1 items-center">
              {theme === 'dark' ? (
                <img alt="" src={logo2} className="h-8 w-auto" />
              ) : (
                <img alt="" src={logo} className="h-8 w-auto" />
              )}
              <span className='px-3 font-bold' id='text'>Harness</span>
            </div>
          </div>
          <NavList
            sections={navSections}
            activeTab={activeTab}
            onSelect={(id) => {
              setActiveTab(id);
              setSidebarOpen(false);
            }}
          />
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 w-full">
        <header className="sticky top-0 z-20 flex h-16 items-center gap-4 border-b bg-background px-6">
          <div className="flex flex-1 items-center gap-4">
            <Button variant="outline" size="icon" className="md:hidden" onClick={toggleSidebar}>
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
            <h1 className="text-xl font-semibold">{currentTabLabel}</h1>
          </div>
          <div className="flex items-center gap-2">
            {user_role === "admin" && (
              <div>
            <Button variant="outline" size="icon" onClick={() => setActiveTab("inbox")}>
              <Bell className="h-5 w-5" />
              <span className="sr-only">Notifications</span>
            </Button>
            <Button variant="outline" size="icon" onClick={() => setActiveTab("settings")}>
              <User className="h-5 w-5" />
              <span className="sr-only">User</span>
            </Button>
              </div>
            )}
            <ThemeToggle />
          </div>
        </header>
        <main className="relative pt-6 px-6 h-[90dvh] w-full " onClick={() => setSidebarOpen(false)}>
          <Suspense fallback={<PageSpinner />}>
            {renderTabContent()}
          </Suspense>
        </main>
      </div>
    </div>
  )
}